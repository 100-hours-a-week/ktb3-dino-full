package com.example.spring_practice.controller;

import com.example.spring_practice.dto.AuthDto;
import com.example.spring_practice.dto.UserDto;
import com.example.spring_practice.entity.User;
import com.example.spring_practice.repository.UserRepository;
import com.example.spring_practice.security.jwt.JwtProvider;
import com.example.spring_practice.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.nio.file.AccessDeniedException;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class AuthController {

    public static final String LOGIN_USER_ID = "LOGIN_USER_ID";
    private final UserRepository userRepository;
    private final UserService userService;
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;
    private final JwtProvider jwtProvider;

    @PostMapping("/join")
    public ResponseEntity<UserDto.Response> join(@RequestBody @Valid UserDto.SignUpRequest req) {
        if (userRepository.existsByEmail(req.getEmail())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .build();
        }

        User user = userRepository.save(User.builder()
                .email(req.getEmail())
                .nickname(req.getNickname())
                .password(req.getPassword())
                .build());

        return ResponseEntity
                .created(URI.create("/api/users/" + user.getId()))
                .body(UserDto.Response.builder()
                        .id(user.getId())
                        .email(user.getEmail())
                        .nickname(user.getNickname())
                        .build());
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody @Valid AuthDto.LoginRequest req, HttpSession session) {
        var user = userRepository.findByEmail(req.getEmail()).orElse(null);
        if (user == null || !user.getPassword().equals(req.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error","UNAUTHORIZED","message","invalid credentials"));
        }
        session.setAttribute(LOGIN_USER_ID, user.getId());
        return ResponseEntity.ok(
                AuthDto.LoginResponse.builder()
                        .userId(user.getId())
                        .nickname(user.getNickname())
                        .email(user.getEmail())
                        .build()
        );
    }

//    @PostMapping("/login")
//    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
//        try {
//            Authentication authentication = authenticationManager.authenticate(
//                    new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword())
//            );
//            System.out.println("로그인 성공!!!!"); //
//            // 인증 성공했으면 토큰 발급
//            String token = jwtProvider.generateToken(req.getEmail());
//
//            return ResponseEntity.ok(new LoginResponse(token));
//        } catch (BadCredentialsException e) {
//            System.out.println("로그인 실패!!!!!"); //
//            return ResponseEntity.status(401).body("invalid credentials");
//        }
//    }
//
//    @Data
//    public static class LoginRequest {
//        private String email;
//        private String password;
//    }
//
//    @Data
//    public static class LoginResponse {
//        private final String accessToken;
//    }

    @GetMapping("/me")
    public ResponseEntity<?> me(HttpSession session) {
        Long uid = (Long) session.getAttribute(LOGIN_USER_ID);
        if (uid == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error","UNAUTHORIZED","message","not logged in"));
        return userRepository.findById(uid)
                .<ResponseEntity<?>>map(u -> ResponseEntity.ok(Map.of(
                        "userId", u.getId(), "nickname", u.getNickname(), "email", u.getEmail()
                ))).orElseGet(() -> {
                    session.invalidate();
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                            .body(Map.of("error","UNAUTHORIZED","message","user not found"));
                });
    }

    @PatchMapping("/me/password")
    public ResponseEntity<?> changeMyPassword(
            @RequestBody @Valid UserDto.ChangePasswordRequest req,
            HttpSession session
    ) {
        Long uid = (Long) session.getAttribute(LOGIN_USER_ID);
        if (uid == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "UNAUTHORIZED", "message", "not logged in"));
        }

        userService.changePassword(uid, req.getNewPassword());
        return ResponseEntity.noContent().build(); // 204
    }

    @PatchMapping("/me/nickname")
    public ResponseEntity<?> updateNickname(
            @RequestBody @Valid UserDto.UpdateNicknameRequest req,
            HttpSession session
    ) {
        Long uid = (Long) session.getAttribute(LOGIN_USER_ID);
        if (uid == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "UNAUTHORIZED", "message", "not logged in"));
        }

        // 유저 조회
        User user = userRepository.findById(uid).orElse(null);
        if (user == null) {
            session.invalidate();
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "UNAUTHORIZED", "message", "user not found"));
        }

        String newNickname = req.getNickname().trim();

        // 닉네임이 동일하면 굳이 업데이트 안 해도 되지만, OK 응답은 주자
        if (newNickname.equals(user.getNickname())) {
            return ResponseEntity.ok(Map.of(
                    "userId", user.getId(),
                    "nickname", user.getNickname(),
                    "email", user.getEmail()
            ));
        }

        user.setNickname(newNickname);
        userRepository.save(user);

        return ResponseEntity.ok(Map.of(
                "userId", user.getId(),
                "nickname", user.getNickname(),
                "email", user.getEmail()
        ));
    }

    @DeleteMapping("/me")
    public ResponseEntity<Void> deleteMe(HttpSession session) {
        Long uid = (Long) session.getAttribute(LOGIN_USER_ID);
        if (uid == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        try {
            userService.deleteAccount(uid);
        } catch (AccessDeniedException e) {
            throw new RuntimeException(e);
        }
        session.invalidate();
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(HttpSession session) {
        session.invalidate();
        return ResponseEntity.noContent().build();
    }




}
