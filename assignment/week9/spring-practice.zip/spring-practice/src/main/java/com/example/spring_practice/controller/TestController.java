package com.example.spring_practice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class TestController {

    @GetMapping("admin")
    public String admin() {
        return "admin";
    }

    @GetMapping("/main")
    public String mainP() {
        return "main";
    }
}
